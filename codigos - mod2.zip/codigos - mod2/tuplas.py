# Explorando o tipo tupla em python
nomes = ('willian', 'joao', 'maria') # Criação de um tupla
print(type(nomes)) # 'tuple'
print(len(nomes))
print('willian' in nomes)
print(nomes[1:2])