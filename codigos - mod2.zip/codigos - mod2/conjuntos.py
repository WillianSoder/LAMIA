#explorando o tipo 'conjuntos'
print({5,6,7})
print(type({5,6,7})) # 'set'
print({5,6,7,7,7,7,6,6,6,5})