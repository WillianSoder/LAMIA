'''Todas execucoes e chamadas de funcao deixei dentro de cada arquivo especifico'''


#import variaveis
#import basicos
#import listas
#import tuplas
#import conjuntos 
#import dicionario
#import operadores
#import controle
#import funcoesbasico
#import args
#import funcional
#import map_reduce
#import lambdas 
#import comprehension
#import POO
#import POOheranca
#import POOmembros