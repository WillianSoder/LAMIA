# Explorando o tipo dicionario em python 
aluno = {
    'nome': 'willian',
    'nota': 9.8,
    'ativo': False
}  # Criando o dicionario 
print(type(aluno)) # 'dict'
print(len(aluno))
print(aluno['nome'])
print(aluno['nota'])
print(aluno['ativo'])
