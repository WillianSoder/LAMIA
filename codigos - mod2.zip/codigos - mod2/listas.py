# Explorando a classe list em python 
numeros = [10, 20, 30]
print(type(numeros)) # 'list'

numeros.append(30) # anexa valor 30 a lista 
print(len(numeros)) # tamnanho da lista

numeros[3] = -54

numeros.insert(0,77) # insere 77 no inicio
print(numeros)

