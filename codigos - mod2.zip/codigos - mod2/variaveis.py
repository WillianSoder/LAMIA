a = 5
b = 6

print(a + b)

texto = 'seu nome é: '
nome = 'Willian'

print(texto + nome)

print(5 * 'olá' )

pi = 3.1415
raio = float(input('Digite o raio:'))

area = pi * raio * raio 

print(f'a area é: {area}m^2')

