# explorando os tipos de dados em python
print(type(1)) # int 
print(type(2.1)) # float
print(type('str')) # string
print(type(True)) # boolean